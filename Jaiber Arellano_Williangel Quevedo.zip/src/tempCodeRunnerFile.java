import java.util.Scanner;

public class tempCodeRunnerFile {
    public static void main(String[] args) throws Exception {
        try (Scanner scan = new Scanner(System.in)) {
            int Salario_b_mensual;
            Salario_b_mensual = scan.nextInt();
            System.out.println(Salario_b_mensual);
        }



    }
}
